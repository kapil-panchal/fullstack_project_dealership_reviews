package com.app60.springreviewscollection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringReviewsCollectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringReviewsCollectionApplication.class, args);
	}

}
