package com.app28.dealershipreviews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DealershipReviewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DealershipReviewsApplication.class, args);
	}

}
