package com.app31.userdetails1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Userdetails1ServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
