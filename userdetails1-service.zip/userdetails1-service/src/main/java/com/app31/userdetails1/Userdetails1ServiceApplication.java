package com.app31.userdetails1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Userdetails1ServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Userdetails1ServiceApplication.class, args);
	}

}
