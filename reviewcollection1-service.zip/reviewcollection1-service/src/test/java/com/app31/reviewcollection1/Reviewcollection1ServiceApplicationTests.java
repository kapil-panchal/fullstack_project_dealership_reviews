package com.app31.reviewcollection1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reviewcollection1ServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
