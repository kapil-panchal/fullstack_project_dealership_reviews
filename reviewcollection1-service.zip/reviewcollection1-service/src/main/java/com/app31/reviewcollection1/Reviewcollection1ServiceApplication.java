package com.app31.reviewcollection1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Reviewcollection1ServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Reviewcollection1ServiceApplication.class, args);
	}

}
